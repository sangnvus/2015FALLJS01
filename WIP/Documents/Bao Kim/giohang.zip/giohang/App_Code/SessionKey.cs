﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SessionKey
/// </summary>
public static class SessionKey
{
    public static string merchantid = "13652";
    public static string securepass = "22fa0b5355848e99";
    public static string apiuser = "roonlinecom";
    public static string apipass = "roonlinecom98djzysf8ijgFUetg";
    public static string Business = "phanvu012@gmail.com";
}