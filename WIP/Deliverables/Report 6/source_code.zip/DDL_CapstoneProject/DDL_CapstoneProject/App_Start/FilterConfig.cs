﻿using System.Web;
using System.Web.Mvc;

namespace DDL_CapstoneProject
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
