﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DDL_CapstoneProject.Models.DTOs
{
    public class NewMessageNumberDTO
    {
        public int ReceivedMessage { get; set; }
        public int SentMessage { get; set; }
    }
}