﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DDL_CapstoneProject.Models.DTOs
{
    public class ProjectTitleDTO
    {
        public string projectTitle { get; set; }
    }
}