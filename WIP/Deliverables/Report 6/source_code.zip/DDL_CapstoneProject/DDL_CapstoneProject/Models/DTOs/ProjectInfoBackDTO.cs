﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DDL_CapstoneProject.Models.DTOs
{
    public class ProjectInfoBackDTO
    {
        public string ProjectCode { get; set; }
        public string Title { get; set; }
        public string Creator { get; set; }
        public string CreatorUsername { get; set; }
    }
}