﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DDL_CapstoneProject.Models.DTOs
{
    public class CategoryDTO
    {
        //attributes
        public int CategoryID { get; set; }
        public string Name { get; set; }
    }
}