﻿"use strict";

service.service("AdminMessageService", function ($http) {

});